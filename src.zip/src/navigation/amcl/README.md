*amcl package description*
-It generates accurate pose data with reference to the map and also publishes tf messages from odom to map
-The parameters in this package decide the accuracy, computational time and compatibility with different bots and environment.
-There two main launch files in the /examples directory, amcl_diff.launch(for differential wheel robot) and amcl_omni.launch

*Parameter usage suggestions*
Important thing to keep in mind before calibrating these parameters are the trade-offs involved.
-Computational time vs Accuracy
-Static environment vs Dynamic environment
-Volume of odom data vs Reliability of odom data

Important parameters for deciding the trade-off outcome:
-To increase accuracy and reduce computation time increase(laser_max_beams, min_particles, max_particles)
-If the environment is more static and with lesser dynamic obstacles increase laser_z_hit and decrease laser_z_rand.
-If transform from base_link to odom are published at a slower rate increase transform_tolerance.
-To increase volume of odom data and also accept high error data increase the odom_alpha1...4 values.


