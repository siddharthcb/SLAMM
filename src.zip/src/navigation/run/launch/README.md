*run package description*
-It controls the navigation performance throught various params files.
-It also consists of the map files for running through move_base.launch

*Parameter calibration suggestions*

1)costmap_common_params.yaml:
-Change footprint data for different sized robots
-Change the inflation radius to maintain navigation tolerance to avoid collision probabilities.
-Increase obstacle range to generate a more efficient path, but at the cost of high computation.

2)global_costmap_params.yaml:
-Increase the update freq if necessary
-Increase the transform_tolerance to gather more tf messages from odom to map published by amcl.

3)local_costmap_params.yaml:
-To increase accuracy and the range of robots awareness of surroundings increase width, height and decrease resolution value and make the costmap finer.
-Change the update_frequency as per necessity

4)base_local_planner_params.yaml:
-Tune velocity and acceleration ranges according to the robots motor limitations and the desired operating speed.
-To increase local path generation accuracy and also computation time increase vx_samples and vtheta_samples.


