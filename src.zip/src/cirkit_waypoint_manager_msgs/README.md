# cirkit_waypoint_manager_msgs  [![Build Status](https://travis-ci.org/CIR-KIT/cirkit_waypoint_manager_msgs.svg?branch=indigo-devel)](https://travis-ci.org/CIR-KIT/cirkit_waypoint_manager_msgs) [![Slack](https://img.shields.io/badge/Slack-CIR--KIT-blue.svg)](https://cir-kit.slack.com/messages/cirkit_waypoint_manager_msgs)
Remote monitoring package for navigation

service msg for [CIR-KIT/cirkit_waypoint_manager](https://github.com/CIR-KIT/cirkit_waypoint_manager/) and [CIR-KIT/remote_monitor](https://github.com/CIR-KIT/remote_monitor).
